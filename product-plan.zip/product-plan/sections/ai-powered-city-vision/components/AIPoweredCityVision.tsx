import type { AIPoweredCityVisionProps } from '../types'
import { HeroSection } from './HeroSection'
import { JourneyRoad } from './JourneyRoad'
import { ContentNode } from './ContentNode'
import { FeatureGrid } from './FeatureGrid'
import { VisualConceptsSection } from './VisualConceptsSection'
import { TeamSection } from './TeamSection'
import { CTASection } from './CTASection'

// Design tokens: cyan (primary), lime (secondary), slate (neutral)
// Fonts: Space Grotesk (heading), Inter (body)

export function AIPoweredCityVision({
  hero,
  goals,
  problems,
  solutions,
  cityFeatures,
  visualConcepts,
  experts,
  callsToAction,
  onNavigate,
  onViewExpert,
}: AIPoweredCityVisionProps) {
  return (
    <div className="relative bg-slate-950 text-white overflow-hidden">
      {/* Google Fonts */}
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      <link
        href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@300;400;500;600&display=swap"
        rel="stylesheet"
      />

      {/* Hero Section */}
      <HeroSection hero={hero} />

      {/* The Journey - Road with connected sections */}
      <div className="relative">
        {/* Visual Road Path (SVG) */}
        <JourneyRoad />

        {/* Goals Section */}
        <section className="relative py-32 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <h2
              className="text-5xl md:text-6xl font-bold text-center mb-4"
              style={{ fontFamily: 'Space Grotesk, sans-serif' }}
            >
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-lime-400">
                Our Vision
              </span>
            </h2>
            <p
              className="text-xl text-slate-400 text-center mb-20 max-w-3xl mx-auto"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Five transformative objectives guiding Ukraine's urban future
            </p>

            <div className="grid gap-8 md:gap-12">
              {goals.map((goal, index) => (
                <ContentNode
                  key={goal.id}
                  title={goal.title}
                  description={goal.description}
                  index={index}
                  side={index % 2 === 0 ? 'left' : 'right'}
                  variant="goal"
                />
              ))}
            </div>
          </div>
        </section>

        {/* Problems Section */}
        <section className="relative py-32 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
          <div className="max-w-7xl mx-auto">
            <h2
              className="text-5xl md:text-6xl font-bold text-center mb-4"
              style={{ fontFamily: 'Space Grotesk, sans-serif' }}
            >
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-400">
                The Challenge
              </span>
            </h2>
            <p
              className="text-xl text-slate-400 text-center mb-20 max-w-3xl mx-auto"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Critical issues demanding systemic transformation
            </p>

            <div className="grid gap-8 md:gap-12">
              {problems.map((problem, index) => (
                <ContentNode
                  key={problem.id}
                  title={problem.title}
                  description={problem.description}
                  index={index}
                  side={index % 2 === 0 ? 'right' : 'left'}
                  variant="problem"
                />
              ))}
            </div>
          </div>
        </section>

        {/* Solutions Section */}
        <section className="relative py-32 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <h2
              className="text-5xl md:text-6xl font-bold text-center mb-4"
              style={{ fontFamily: 'Space Grotesk, sans-serif' }}
            >
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-lime-400 to-emerald-400">
                The Solution
              </span>
            </h2>
            <p
              className="text-xl text-slate-400 text-center mb-20 max-w-3xl mx-auto"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              How AI-powered cities transform governance and society
            </p>

            <div className="grid gap-8 md:gap-12">
              {solutions.map((solution, index) => (
                <ContentNode
                  key={solution.id}
                  title={solution.title}
                  description={solution.description}
                  index={index}
                  side={index % 2 === 0 ? 'left' : 'right'}
                  variant="solution"
                />
              ))}
            </div>
          </div>
        </section>

        {/* Visual Concepts Section */}
        <VisualConceptsSection concepts={visualConcepts} />

        {/* City Features Section */}
        <section className="relative py-32 px-4 sm:px-6 lg:px-8 bg-slate-900/50">
          <div className="max-w-7xl mx-auto">
            <h2
              className="text-5xl md:text-6xl font-bold text-center mb-4"
              style={{ fontFamily: 'Space Grotesk, sans-serif' }}
            >
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">
                Smart Infrastructure
              </span>
            </h2>
            <p
              className="text-xl text-slate-400 text-center mb-20 max-w-3xl mx-auto"
              style={{ fontFamily: 'Inter, sans-serif' }}
            >
              Integrated systems powering the cities of tomorrow
            </p>

            <FeatureGrid features={cityFeatures} />
          </div>
        </section>

        {/* Team Section */}
        <TeamSection experts={experts} onViewExpert={onViewExpert} />

        {/* CTA Section */}
        <CTASection callsToAction={callsToAction} onNavigate={onNavigate} />
      </div>
    </div>
  )
}
